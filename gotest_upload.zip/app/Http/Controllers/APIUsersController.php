<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User; 

use DB;
use Tymon\JWTAuth\Contracts\JWTSubject;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Response;
use Validator;
use JWTAuth;





class APIUsersController extends Controller
{
    public function getAllUsers(){

      $id = auth()->id();

	  $result = User::join('model_has_roles', 'model_has_roles.model_id', '=', 'users.id')
      ->join('roles', 'roles.id', '=', 'model_has_roles.role_id')
       ->select('users.*', 'model_has_roles.role_id','roles.name')
      ->where('users.id', '!=', $id)->get();
      //Dowload Image
      //return response()->download(public_path('/images/users/002.jpg'), 'User image');


    return $result;
    }
    
    public function createUser(Request $request)
    {
        
             $validator = Validator::make($request -> all(),[
            'email' => 'required|string|email|max:255|unique:users',
            'firstname' => 'required',
            'lastname' => 'required',
            'password' => 'required'
        ]);

        if ($validator -> fails()) {
            return response()->json($validator->errors());
        }

        User::create([

            'firstname' => $request->get('firstname'),
            'lastname' => $request->get('lastname'),
            'email' => $request->get('email'),
            'password' => bcrypt($request->get('password')),
            'image' => $request->get('image'),
            'gender' => $request->get('gender'),
            'birthday' => $request->get('birthday'),
            'cin' => $request->get('cin'),
            'city' => $request->get('city'),
            'phone' => $request->get('phone'),
            'adresse' => $request->get('adresse')
        ]);

        $user = User::first();
        $token = JWTAuth::fromUser($user);
        return Response::json($user);
    }
    
      public function deleteUser($id)
    {
         $User = User::findOrFail($id);
		    if($User){
                DB::table('model_has_roles')->where('model_id', '=', $User->id)->delete(); 
		       $User->delete();

		    }else{
		        return response()->json(error);
            }
		    return response()->json(null); 
    }

     public function updateUser( Request $request, $id){
  $User = User::find($id);

           $validator = Validator::make($request -> all(),[
           
            'firstname' => 'string',
            'lastname' => 'string',
            'city' => 'string|max:255|',
            'birthday' => 'birthday',
            'image' => 'string',            
            'password' => 'lamepassword'
        ]);

       if ($validator -> fails()) {
            return response()->json($validator->errors());
        }

        $request->merge([

            //$User->email = $request->input('email'),
            $User->firstname = $request->input('firstname'),
            $User->lastname = $request->input('lastname'),
            $User->city = $request->input('city'),
            $User->image = $request->input('image'),            
            $User->password  = $request->input('password')
    ]);
    

          $User->save();

        return response()->json($User);

    }



}
